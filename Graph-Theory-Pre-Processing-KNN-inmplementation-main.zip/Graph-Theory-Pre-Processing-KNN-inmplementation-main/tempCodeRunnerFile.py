from sklearn.model_selection import train_test_split
from gspan_mining.config import parser
from gspan_mining.main import main
import networkx as nx
from sklearn.metrics import jaccard_score
from sklearn.model_selection import train_test_split
import numpy as np
from sklearn.metrics import confusion_matrix
import functions